package userInterface;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import  game.Game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import java.awt.event.ActionListener;

import javax.swing.*;

/**
 *
 * @author kwhiting
 */
public class ScraggleUI
{
    private static final Color MIDNIGHT_PURPLE = new Color(102,0,153);
    
    // top level containter
    JFrame frame;
    Game game;
    
   
    //Components for Current Word panel
    JPanel curWordPanel;
    JLabel curWordLabel;
    JLabel playerScoreLabel;
    JButton submitButton;
    
    //Components for Scraggle Board panel
    JPanel boardPanel;
    JButton die [] [];
    
    //Components for information panel
    JPanel infoPanel;
    JTextArea textArea;
    JTextPane wordsPane;
    JScrollPane scrollPane;
    JLabel timeLabel;
    JButton shakeButton;
    
    
    //Menu components 
    JMenuBar menuBar;   //Creates area to add menu items
    JMenu Scraggle;     //A "dropDown" tab
    
    //JMenuItems are Individual items in the "dropDown" tab
    JMenuItem newGame;  
    JMenuItem exit;
    
   
    
    /**
     *
     * @param passedGame
     */
    public ScraggleUI(Game passedGame)
    {
        this.game = passedGame;
        initComponents();
    }
    
    
    private void initComponents()
    {
        
        // Initialize the JFrame
        frame = new JFrame("Scraggle");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(620,500));
        frame.setLayout(new BorderLayout());

        // Initialize the JMenuBar and add to the JFrame
        menuBar = new JMenuBar();
        
        // Initialize the File menu and add the JMenuItems with action listener
        Scraggle = new JMenu("Scraggle");
        newGame = new JMenuItem("New Game");
        exit = new JMenuItem("Exit");
        
        // Adding our new game and exit buttons to the dropdown menu
        Scraggle.add(newGame);
        Scraggle.add(exit);
        
        // Add our menu to the actual JMenuBar
        menuBar.add(Scraggle);
        
        // Place the JMenuBar onto the JFrame.
        frame.setJMenuBar(menuBar);
        
        
 
        
        //Current Word Panel configuration
        curWordPanel = new JPanel(new FlowLayout());
        curWordLabel = new JLabel();
        playerScoreLabel = new JLabel();
        submitButton = new JButton("Submit Word");
        submitButton.setBackground(MIDNIGHT_PURPLE);
        submitButton.setOpaque(true);
        submitButton.setBorderPainted(false);
        
        //Set dimensions for elements in the Current word panel
        curWordLabel.setPreferredSize(new Dimension(250, 50));
        submitButton.setPreferredSize(new Dimension(200, 75));
        playerScoreLabel.setPreferredSize(new Dimension(120,50));
        
        //Set Bordering for Current word panels and labels.
        curWordPanel.setBorder(BorderFactory.createTitledBorder("Current Word"));
        curWordLabel.setBorder(BorderFactory.createTitledBorder("Current Word"));
        playerScoreLabel.setBorder(BorderFactory.createTitledBorder("Score"));
        
        //Add our 2 labels and 1 button to our Current Word panel
        curWordPanel.add(curWordLabel);
        curWordPanel.add(submitButton);
        curWordPanel.add(playerScoreLabel);
        
      
        //Scraggle Board Panel configuration
        boardPanel = new JPanel(new GridLayout(4, 4));
        boardPanel.setBorder(BorderFactory.createTitledBorder("Scraggle Board"));
        die = new JButton [4] [4];
        
        //Adding our buttons to the boardPanel
        for(int i = 0; i < 4; i++)
        {
            for(int j = 0; j < 4; j++)
            {
               die[i] [j] = new JButton();
               (die [i] [j]).setBackground(MIDNIGHT_PURPLE);
               (die [i] [j]).setOpaque(true);
               (die [i] [j]).setBorderPainted(true);
               boardPanel.add(die[i] [j]);
              
            }
        }  
        
      
        
        
        //info panel configuration
        infoPanel = new JPanel();
        infoPanel.setBorder(BorderFactory.createTitledBorder("Enter Words Found"));
        infoPanel.setLayout(new GridLayout(3,1));
       
        //Text area and scroll configuration
        wordsPane = new JTextPane();
        wordsPane.setPreferredSize(new Dimension(30, 25));
        wordsPane.setPreferredSize(new Dimension(290,100));
       
        scrollPane = new JScrollPane(wordsPane);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        
        
        
        
        //Timer label configuration
        timeLabel = new JLabel("3:00", JLabel.CENTER);
        timeLabel.setMinimumSize(new Dimension(290,100));
        timeLabel.setBorder(BorderFactory.createTitledBorder("Time Left"));
        timeLabel.setFont(new Font("Times New Roman", Font.PLAIN, 50));
        
        
        
        //Shake Dice button configuration
        shakeButton = new JButton();
        shakeButton.setText("*  Shake Dice  *");
        shakeButton.setMinimumSize(new Dimension(290,100));
        shakeButton.setBackground(MIDNIGHT_PURPLE);
        shakeButton.setOpaque(true);
        shakeButton.setBorderPainted(false);
         
        //Adding elements to our information panel
        infoPanel.add(scrollPane);
        infoPanel.add(timeLabel);
        infoPanel.add(shakeButton);
        

        //Adding all panels to our main frame.
        frame.add(curWordPanel, BorderLayout.SOUTH);
        frame.add(infoPanel, BorderLayout.EAST);
        frame.add(boardPanel, BorderLayout.WEST);
        
       
       

        frame.setVisible(true);
//        frame.revalidate();
//        frame.repaint();
    }    

    // inner class
/*    private class ThisListener implements ActionListener {

        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
System.out.println("button clicked");
            System.out.println(text.getText());
                    eastLabel.setText(text.getText());

        } */
}

